<?php namespace Arcanedev\Support\Exceptions;

use Exception;

/**
 * Class     PackageException
 *
 * @package  Arcanedev\Support\Exceptions
 * @author   ARCANEDEV <arcanedev.maroc@gmail.com>
 */
class PackageException extends Exception {}
