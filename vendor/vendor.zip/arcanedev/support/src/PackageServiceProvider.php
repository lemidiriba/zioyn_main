<?php namespace Arcanedev\Support;

/**
 * Class     PackageServiceProvider
 *
 * @package  Arcanedev\Support\Laravel
 * @author   ARCANEDEV <arcanedev.maroc@gmail.com>
 *
 * @deprecated  Use `Arcanedev\Support\Providers\PackageServiceProvider` instead
 */
abstract class PackageServiceProvider extends Providers\PackageServiceProvider
{
    //
}
