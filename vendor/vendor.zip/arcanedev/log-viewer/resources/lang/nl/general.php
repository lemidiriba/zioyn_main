<?php

return [
    'all'        => 'Alles',
    'date'       => 'Datum',
    'empty-logs' => 'De lijst met logs is leeg!',
];
