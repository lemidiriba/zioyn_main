<?php

return [
    'all'        => 'すべて',
    'date'       => '日付',
    'empty-logs' => 'ログリストが空です!',
];
