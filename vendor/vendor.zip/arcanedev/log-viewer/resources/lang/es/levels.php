<?php

return [
    'all'       => 'Todos',
    'emergency' => 'Emergencia',
    'alert'     => 'Alerta',
    'critical'  => 'Criticos',
    'error'     => 'Errores',
    'warning'   => 'Advertencia',
    'notice'    => 'Aviso',
    'info'      => 'Info',
    'debug'     => 'Debug',
];
