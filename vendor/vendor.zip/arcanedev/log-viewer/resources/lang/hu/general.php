<?php

return [
    'all'        => 'Összes',
    'date'       => 'Dátum',
    'empty-logs' => 'The list of logs is empty!',
];
