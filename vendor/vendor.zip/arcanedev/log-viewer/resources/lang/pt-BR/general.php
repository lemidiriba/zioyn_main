<?php

return [
    'all'        => 'Todos',
    'date'       => 'Data',
    'empty-logs' => 'A lista de logs está vazia!',
];
