<?php

return [
    'all'        => '全部',
    'date'       => '日期',
    'empty-logs' => '列表中沒有任何紀錄！',
];
