<?php

return [
    'all'       => '全部',
    'emergency' => '緊急',
    'alert'     => '警報',
    'critical'  => '嚴重',
    'error'     => '錯誤',
    'warning'   => '警告',
    'notice'    => '注意',
    'info'      => '訊息',
    'debug'     => '除錯',
];
