<?php

return [
    'all'        => 'All',
    'date'       => 'Date',
    'empty-logs' => 'The list of logs is empty!',
];
