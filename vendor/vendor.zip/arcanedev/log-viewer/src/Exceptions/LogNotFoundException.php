<?php namespace Arcanedev\LogViewer\Exceptions;

/**
 * Class     LogNotFoundException
 *
 * @package  Arcanedev\LogViewer\Exceptions
 * @author   ARCANEDEV <arcanedev.maroc@gmail.com>
 */
class LogNotFoundException extends LogViewerException {}
