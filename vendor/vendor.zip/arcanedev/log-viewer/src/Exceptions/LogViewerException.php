<?php namespace Arcanedev\LogViewer\Exceptions;

/**
 * Class     LogViewerException
 *
 * @package  Arcanedev\LogViewer\Exceptions
 * @author   ARCANEDEV <arcanedev.maroc@gmail.com>
 */
class LogViewerException extends \Exception {}
