<?php

return [
    'self_diagnosis' => [
        'common_checks' => 'Allgemeine Überprüfungen',
        'environment_specific_checks' => 'Umgebungsspezifische Überprüfungen (:environment)',
        'failed_checks' => 'Folgende Überprüfungen sind fehlgeschlagen:',
        'running_check' => '<fg=yellow>Überprüfung :current/:max:</fg=yellow> :name...  ',
        'success' => 'Gute Arbeit, sieht so aus, als wäre alles richtig eingestellt!',
    ],
];
