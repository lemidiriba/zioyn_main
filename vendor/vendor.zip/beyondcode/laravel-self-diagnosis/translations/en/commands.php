<?php

return [
    'self_diagnosis' => [
        'common_checks' => 'Common Checks',
        'environment_specific_checks' => 'Environment Specific Checks (:environment)',
        'failed_checks' => 'The following checks failed:',
        'running_check' => '<fg=yellow>Running check :current/:max:</fg=yellow> :name...  ',
        'success' => 'Good job, looks like you are all set up!',
    ],
];
