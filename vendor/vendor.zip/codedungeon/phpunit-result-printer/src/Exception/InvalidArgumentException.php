<?php

namespace PHPUnitPrettyResultPrinter\Exception;

class InvalidArgumentException extends \Exception
{
}
