<?php

declare(strict_types=1);

namespace Altek\Accountant\Exceptions;

use Exception;

class AccountantException extends Exception
{
}
