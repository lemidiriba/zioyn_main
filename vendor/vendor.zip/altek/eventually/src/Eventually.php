<?php

declare(strict_types=1);

namespace Altek\Eventually;

trait Eventually
{
    use Concerns\HasEvents;
    use Concerns\HasRelationships;
}
